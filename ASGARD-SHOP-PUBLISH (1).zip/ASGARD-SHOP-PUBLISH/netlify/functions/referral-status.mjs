import { getStore } from '@netlify/blobs';
const json = (statusCode, body) => ({ statusCode, headers:{'content-type':'application/json','cache-control':'no-store'}, body:JSON.stringify(body) });
export const handler = async (event) => {
  if (event.httpMethod !== 'GET') return json(405,{error:'Method not allowed.'});
  const code = String(event.queryStringParameters?.code || '').trim().toLowerCase();
  if (!/^[a-f0-9]{24}$/.test(code)) return json(400,{error:'Invalid referral code.'});
  const store = getStore({name:'asgard-referrals',consistency:'strong'});
  const owner = await store.get(`code:${code}`,{type:'json'});
  if (!owner) return json(404,{error:'Referral code not found.'});
  const list = await store.list({prefix:`earned:${code}:`});
  const count = (list.blobs || []).length;
  const reward = await store.get(`reward:${code}`,{type:'json'});
  return json(200,{qualifyingPurchases:count,needed:Math.max(0,2-count),rewardEarned:!!reward, reward:reward?.status || 'in_progress'});
};
