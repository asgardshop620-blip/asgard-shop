import { getStore } from '@netlify/blobs';
import { createHash, randomUUID } from 'node:crypto';

const WALLET = '3isc3qK1JAA6xh1SVwa2DPu2qBtVUseyMG4DxpfX9zgH';
// Official USDT SPL mint on Solana Mainnet.
const USDT_MINT = 'Es9vMFrzaCERmJfrF4H2FYD4KCoNkY11McCe8BenwNYB';
const RPC_URL = process.env.SOLANA_RPC_URL || 'https://api.mainnet-beta.solana.com';
const PRODUCTS = new Map([
  ['NETFLIX PREMIUM / 1 Month',20.01],['NETFLIX PREMIUM / 2 Months',40],['NETFLIX PREMIUM / 3 Months',56],['NETFLIX PREMIUM / 6 Months',100],['NETFLIX PREMIUM / 1 Year',140],
  ['Spotify Premium / 1 Month',6],['Spotify Premium / 2 Months',11],['Spotify Premium / 3 Months',13],['Spotify Premium / 6 Months',20],['Spotify Premium / 1 Year',60],
  ['Disney+ / 1 Month',14],['Disney+ / 2 Months',27],['Disney+ / 3 Months',40],['Disney+ / 6 Months',75],
  ['XBOX GAME PASS ULTIMATE / 1 Month',17],['XBOX GAME PASS ULTIMATE / 3 Months',54],['XBOX GAME PASS ULTIMATE / 6 Months',85],['XBOX GAME PASS ULTIMATE / 1 Year',180]
]);
const json = (statusCode, body) => ({ statusCode, headers: { 'content-type':'application/json', 'cache-control':'no-store', 'x-content-type-options':'nosniff' }, body: JSON.stringify(body) });
const emailHash = (email) => createHash('sha256').update(email).digest('hex');
async function rpc(method, params) {
  const r = await fetch(RPC_URL, { method:'POST', headers:{'content-type':'application/json'}, body:JSON.stringify({jsonrpc:'2.0',id:1,method,params}), signal: AbortSignal.timeout(12000) });
  if (!r.ok) throw new Error('Solana verification service is unavailable. Try again shortly.');
  const j = await r.json(); if (j.error) throw new Error('Solana could not verify this transaction.'); return j.result;
}
async function verifyPayment(signature, expectedUsd) {
  if (!/^[1-9A-HJ-NP-Za-km-z]{80,100}$/.test(signature)) throw new Error('Transaction signature format is invalid.');
  const status = await rpc('getSignatureStatuses', [[signature], { searchTransactionHistory:true }]);
  const st = status?.value?.[0];
  if (!st || st.err || st.confirmationStatus !== 'finalized') throw new Error('Payment is not finalized on Solana yet. Wait a little, then submit the signature again.');
  const tx = await rpc('getTransaction', [signature, { encoding:'jsonParsed', commitment:'finalized', maxSupportedTransactionVersion:0 }]);
  if (!tx || tx.meta?.err) throw new Error('Transaction failed or cannot be found.');
  const pre = tx.meta.preTokenBalances || [], post = tx.meta.postTokenBalances || [];
  // Use integer base units (USDT has 6 decimals), not floating-point UI amounts.
  let receivedBaseUnits = 0n;
  for (const after of post) {
    if (after.mint !== USDT_MINT || after.owner !== WALLET) continue;
    const before = pre.find(x => x.accountIndex === after.accountIndex && x.mint === USDT_MINT && x.owner === WALLET);
    const a = BigInt(after.uiTokenAmount?.amount || '0');
    const b = BigInt(before?.uiTokenAmount?.amount || '0');
    if (a > b) receivedBaseUnits += a - b;
  }
  const expectedBaseUnits = BigInt(Math.round(expectedUsd * 1_000_000));
  if (receivedBaseUnits !== expectedBaseUnits) {
    const received = (Number(receivedBaseUnits) / 1_000_000).toFixed(6);
    throw new Error(`This transaction delivered ${received} USDT to the store, but this plan requires ${expectedUsd.toFixed(2)} USDT.`);
  }
}
async function saveOnce(store, key, value) {
  // Netlify Blobs' conditional write prevents two concurrent requests reusing the same signature.
  const result = await store.set(key, JSON.stringify(value), { onlyIfNew:true });
  return result?.modified === true;
}
async function creditReferral(referrals, code, buyerEmail, orderId) {
  if (!code || !/^[a-f0-9]{24}$/.test(code)) return { credited:false };
  const mapping = await referrals.get(`code:${code}`, { type:'json' });
  if (!mapping || mapping.emailHash === emailHash(buyerEmail)) return { credited:false };
  const earnedKey = `earned:${code}:${emailHash(buyerEmail)}`;
  const added = await saveOnce(referrals, earnedKey, { orderId, createdAt:new Date().toISOString() });
  const list = await referrals.list({ prefix:`earned:${code}:` });
  const count = (list.blobs || []).length;
  if (count >= 2) await referrals.setJSON(`reward:${code}`, { status:'earned', qualifyingPurchases:count, earnedAt:new Date().toISOString() });
  return { credited:added, count, rewardEarned:count >= 2 };
}
export const handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405,{error:'Method not allowed.'});
  let body; try { body = JSON.parse(event.body || '{}'); } catch { return json(400,{error:'Invalid request.'}); }
  const email = String(body.email || '').trim().toLowerCase();
  const product = String(body.product || '').trim();
  const price = Number(body.price);
  const signature = body.transactionSignature ? String(body.transactionSignature).trim() : '';
  const referralCode = String(body.referralCode || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254) return json(400,{error:'Enter a valid email address.'});
  if (!PRODUCTS.has(product) || !Number.isFinite(price) || Math.abs(PRODUCTS.get(product)-price)>0.001) return json(400,{error:'Selected product or price is invalid. Refresh the page and try again.'});
  if (referralCode && !/^[a-f0-9]{24}$/.test(referralCode)) return json(400,{error:'Referral link is invalid. Ask your friend for a new link.'});
  const orders = getStore({ name:'asgard-orders', consistency:'strong' });
  const referrals = getStore({ name:'asgard-referrals', consistency:'strong' });
  const orderId = randomUUID();
  let paymentStatus = 'pending';
  if (signature) {
    try {
      const seen = await orders.get(`tx:${signature}`, { type:'json' });
      if (seen) return json(409,{error:'This transaction signature has already been used.'});
      await verifyPayment(signature, price);
      const reserved = await saveOnce(orders, `tx:${signature}`, { orderId, createdAt:new Date().toISOString() });
      if (!reserved) return json(409,{error:'This transaction signature has already been used.'});
      paymentStatus = 'verified';
    } catch (e) { return json(400,{error:e.message || 'Payment verification failed.'}); }
  }
  const referralCodeForBuyer = randomUUID().replaceAll('-','').slice(0,24);
  const order = { orderId, email, emailHash:emailHash(email), product, price, currency:'USDT', paymentStatus, transactionSignature:signature || null, referralCode:referralCodeForBuyer, referredBy:referralCode || null, createdAt:new Date().toISOString() };
  try {
    await orders.setJSON(`order:${orderId}`, order);
    await referrals.setJSON(`code:${referralCodeForBuyer}`, { orderId, emailHash:order.emailHash, createdAt:order.createdAt });
    let referral = null;
    if (paymentStatus === 'verified' && referralCode) referral = await creditReferral(referrals, referralCode, email, orderId);
    if (process.env.RESEND_API_KEY && process.env.ADMIN_EMAIL) {
      const emailBody = `Order: ${orderId}\nEmail: ${email}\nProduct: ${product}\nAmount: ${price} USDT\nPayment: ${paymentStatus}\nTransaction: ${signature || 'not provided'}\nReferral: ${referralCode || 'none'}`;
      try { await fetch('https://api.resend.com/emails',{method:'POST',headers:{Authorization:`Bearer ${process.env.RESEND_API_KEY}`,'Content-Type':'application/json'},body:JSON.stringify({from:process.env.EMAIL_FROM || 'ASGARD SHOP <onboarding@resend.dev>',to:[process.env.ADMIN_EMAIL],subject:`ASGARD SHOP order ${orderId} (${paymentStatus})`,text:emailBody}),signal:AbortSignal.timeout(8000)}); } catch (e) { console.error('Order email notification failed',e); }
    }
    return json(200,{orderId,paymentStatus,referralCode:referralCodeForBuyer,referralCount:referral?.count || 0,rewardEarned:referral?.rewardEarned || false,message:paymentStatus==='verified'?'Payment verified on Solana and order saved. Subscription delivery still requires configured inventory/fulfilment.':'Order saved as PENDING. Do not treat it as paid until a valid transaction signature is submitted and verified.'});
  } catch (e) {
    console.error('Order save failed',e);
    return json(500,{error:'The order could not be saved. Do not pay again yet; contact support with this message.'});
  }
};
